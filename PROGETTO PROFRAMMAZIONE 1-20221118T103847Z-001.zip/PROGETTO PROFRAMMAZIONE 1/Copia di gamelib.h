#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
void chiudi();
int termina_gioco();
void gioca();
void crea_cunicoli();
void ins_caverna();
void canc_caverna();
void ins_caverna_abbatti();
void regolescontrofinale();

int menu();
enum quantita_melassa{
  nessuna,
  poca,
  molta
};
enum tipo_imprevisto{
  crollo,
  baco,
  nessun_imprevisto
};
enum tipo_caverna{
  normale,
  speciale,
  accidentata,
  uscita
};
enum tipo_caverna_abbatti{
  normale1,
  speciale1,
  accidentata1,
  uscita1
};
struct Scavatrice{
  int serbatoio_energia;

  int serbatoio_raccolta;

};
typedef struct Scavatrice qq_melassa;


struct Caverna{
  struct Caverna* avanti;
  struct Caverna* destra;
  struct Caverna* sinistra;

  enum tipo_caverna_abbatti caverna_abbatti;
  enum tipo_caverna caverna;
  enum tipo_imprevisto imprevisto;
  enum quantita_melassa melassa;
};

#include <stdio.h>
#include <stdlib.h>
#include "gamelib.h"
int main(){
int a,b,i=0,k=0,z,g=0,v,giri=0,numero1,prob_incontro=-3,numero_turno=0,probabilita_incontrarsi;
char tempo;
time_t t;
srand ((unsigned) time(&t));

for(int probi=1;probi<5;probi++)
probabilita_incontrarsi=rand()%100;

do{
if((probabilita_incontrarsi>0)&&(probabilita_incontrarsi<prob_incontro)){
  printf("LE DUE SCAVATRICI SI SONO INCONTRATE NEL PERCORSO ANDREMO DIRETTAMENTE ALLO SCONTRO FINALE\n");
  regolescontrofinale();
  scontrofinale(i);
}else{

if(i%2==0){


do{
z=0;
system("clear");
printf("TURNO ARVAIS NUMERO  [%d]\n1)CREA CUNICOLI\n2)GIOCA\n3)TERMINA\n",numero_turno);
scanf("%d",&a);

  if(a==1){
    if(k==0){
      crea_cunicoli(i,giri);
      k++;
    }else{
      printf("NON PUOI CREARE PIU'DI UNA VOLTA I CUNICOLI\n");
      z++;
    }
    }else if(a==2){
      if(k!=0){
      gioca(i,numero_turno);
    }else{
      printf("NON PUOI GIOCARE SENZA AVER CREATO UNA MAPPA PRIMA\n");
      z++;
    }
  }else if(a==3){
      return 0;
    }else{
          printf("NON VA BENE,RIDAMMI IL VALORE\n");
          z++;
    }
}while(z!=0);

  system("clear");
}else{

do{
system("clear");
  v=0;
printf("TURNO HARTORNEN NUMERO[%d]\n1)CREA CUNICOLI\n2)GIOCA\n3)TERMINA\n",numero_turno);
scanf("%d",&b);
  if(b==1){
    if(g==0){
      crea_cunicoli(i,giri);
      g++;
    }else{
      printf("NON PUOI CREARE PIU'DI UNA VOLTA I CUNICOLI\n");
      v++;
    }
  }else if(b==2){
    if(g!=0){
    prob_incontro+=3;
    gioca(i,numero_turno);
  }else{
    printf("NON PUOI GIOCARE SENZA AVER CREATO UNA MAPPA PRIMA\n");
    v++;
  }
}else if(b==3){
    return 0;
  }else{
    printf("NON VA BENE,RIDAMMI IL VALORE\n");
    v++;
  }
}while(v!=0);
  system("clear");
numero_turno++;
}
}
i++;

prob_incontro+=3;

}while((a!=3)&&(b!=3));

}

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include "gamelib.h"

static struct Scavatrice Scavatrice;

static struct Caverna * primo_cunicolo_arvais=NULL;
static struct Caverna * ultimo_cunicolo_arvais = NULL;

static struct Caverna * primo_cunicolo_hartornen=NULL;
static struct Caverna * ultimo_cunicolo_hartornen = NULL;

static struct Caverna * primo_cunicolo_aggira=NULL;

static char * getStringtipo_caverna(int);
static char * tipo_caverna_strings [] ={"normale","speciale","accidentata","uscita"};
static int getEnumtipo_caverna(char * string);
static char * getStringtipo_caverna(int v){
    return tipo_caverna_strings[v];
}

static int getEnumtipo_caverna(char * string){
    int result=-1;
    for(int i=0; i<4; i++){
            if(strcmp(tipo_caverna_strings[i],string)==0){
            result=i;
            break;
        }
    }

    if(result==-1){
    system("clear");
        printf("\nTIPOLOGIA DI CAVERNA ERRATO,RIPROVA\n");}

    return result;
}
static char * getStringquantita_melassa(int);
static char * quantita_melassa_strings[]={"nessuna","poca","molta"};
static char * getStringquantita_melassa(int m){
  return quantita_melassa_strings[m];
}

static char * getStringtipo_imprevisto(int);
static char * tipo_imprevisto_strings[]={"nessun_imprevisto","crollo","baco"};
static char * getStringtipo_imprevisto(int s){
  return  tipo_imprevisto_strings[s];
}

static char * getStringtipo_caverna_abbatti(int);
static char * tipo_caverna_abbatti_strings[]={"normale","speciale","accidentata","uscita"};
static char * getStringtipo_caverna_abbatti(int tipo_abbatti){
  return tipo_caverna_abbatti_strings[tipo_abbatti];
}

int probabilita_melassa(int a){
  time_t t;
  srand ((unsigned) time(&t));
  a=rand()%100;
  return a;
}

int probabilita_imprevisto(int k){
  time_t t;
  srand ((unsigned) time(&t));
for(int g=1;g<3;g++){
  k=rand()%100;
}
  return k;
}

int probabilita_stato(int stato){
  time_t t;
  srand ((unsigned) time(&t));
for(int prob=1;prob<4;prob++){
  stato=rand()%100;
}
  return stato;
}

int probabilita_imprevisto_improvviso(){
  int imp_imp;
  time_t t;
  srand ((unsigned) time(&t));
for(int prob=1;prob<4;prob++){
  imp_imp=rand()%100;
}
  return imp_imp;
}


struct Caverna * ricordo_arvais=NULL;
struct Caverna * ricordo_hartornen=NULL;
struct Caverna * ricordo;
struct Caverna * primo_cunicolo;
struct Caverna * ultimo_cunicolo;
struct Caverna * primo_stampa;
struct Caverna * ultimo_avanza,*primo_avanza;
struct Caverna * primo_abbatti,*ultimo_abbatti;
struct Caverna * cancella;

static qq_melassa q_arvais;
static qq_melassa q_hartornen;
static qq_melassa melassa_generica;

char* nome_vincitore;
int scelta,rigioca,rigiocamenu,a,b;
int numero1=0;
int numero=0;
int sceltauscita;
int fine=0;
int servi=0;
int variabile_gioco;
int conta_avanza=0;
int scelta_serbatio=1;
int tipo_caverna_abbatti;
int numero_caverna=0;
int juve=0;
int conta1=0;
int c,conta=0;
int canta_avanza=0;
int pos;
int prob_stato;
int tipo_abbatti_prob;
int m,n,q;
double uscita2=5;
int c;
int quantita_melassa;
int p;
int tipo_imprevisto;
int pbr;
int regole=0;
int scelta_aggira;
int ridammelo=0;
int passaggio_turno;
int sceltat=0;
int serbatoio_ene=4,serbatoio_rac=0;
int colpo,difesa,passaggio_turn;
char tipologia [15];
int first;
int posizione;
char* nome_turno;
int serbatoio,variabile;
int conta_scontrof=0;
int temp;
int r;
int giri=0;
int numero_turno_gioca=0;


void crea_cunicoli();
void ins_caverna();
void canc_caverna();
void stampa_cunicolo();
int chiudi_cunicolo();
void avanza();
void abbatti();
void aggira();
void gioca();
void turno();
void regolescontrofinale();
int scontrofinale();
void esci();
void congratulations();

int prob_incontro=0;

int ab;

int menu(int turno,int probabilita_incontrarsi){
  if((probabilita_incontrarsi>0)&&(probabilita_incontrarsi<prob_incontro)){
    printf("LE DUE SCAVATRICI SI SONO INCONTRATE NEL PERCORSO ANDREMO DIRETTAMENTE ALLO SCONTRO FINALE\n");
    regolescontrofinale();
    ab=scontrofinale(turno);
    return ab;
  }else{
  if(turno%2==0){
do{
b=0;
    printf("TURNO ARVAIS NUMERO\n1)CREA CUNICOLI\n2)GIOCA\n3)TERMINA\n");
    scanf("%d",&scelta);
    if(scelta==1){
      if(ricordo_arvais!=NULL){
        system("clear");
        printf("HAI GIA' CREATO IL TUO PERCORSO NON PUOI RICREARLO\n");
        b=1;
      }else{
        crea_cunicoli(turno);
        giri=0;
      }
    }
    else if(scelta==2){
         if(ricordo_arvais==NULL){
            system("clear");
            printf("NON PUOI GIOCARE SENZA PRIMA CREARE UNA MAPPA\n");
            b=1;
          }else{
          system("clear");
          gioca(turno);
          }
        }else if(scelta==3){
return termina_gioco();

    }
    else{
      system("clear");
      printf("RIDAMMI IL VALORE\n");
  }
}while(((scelta!=1)&&(scelta!=2)&&(scelta!=3))||(b==1));
  }else{
do{
 a=0;
    printf("TURNO HARTORNEN NUMERO\n1)CREA CUNICOLI\n2)GIOCA\n3)TERMINA\n");
    scanf("%d",&scelta);
    if(scelta==1){
       if(ricordo_hartornen!=NULL){
        system("clear");
        printf("HAI GIA' CREATO IL TUO PERCORSO NON PUOI RICREARLO\n");
        a=1;
      }else{
        crea_cunicoli(turno);
      }}
    else if(scelta==2){
      if(ricordo_hartornen==NULL){
         system("clear");
         printf("NON PUOI GIOCARE SENZA PRIMA CREARE UNA MAPPA\n");
         a=1;
       }else{
      system("clear");
       gioca(turno);
       }
    }
    else if(scelta==3){
    return termina_gioco(turno);

    }
    else{
      system("clear");
      printf("RIDAMMI IL VALORE\n");
  }
}while(((scelta!=1)&&(scelta!=2)&&(scelta!=3))||(a==1));
  }

}
printf("%d\n", q_arvais.serbatoio_energia);
if(q_arvais.serbatoio_energia<0)
return termina_gioco(turno);


if(q_hartornen.serbatoio_energia<0)
return termina_gioco(turno);

if(scelta_aggira==2)
return termina_gioco(turno);



  prob_incontro+=3;



}

void crea_cunicoli(int c){

do{
do{
      printf("\n\n\t\t\t\t1......INSERISCI CAVERNA\n\t\t\t\t2.......CANCELLA CAVERNA\n\t\t\t\t3........STAMPA CUNICOLI\n\t\t\t\t4........CHIUDI CUNICOLI\n\n\t\t\t\tSCELTA: ");
      scanf("%d",&sceltat);
}while ((sceltat<1)&&(sceltat>4));
switch (sceltat) {
  case 1: system("clear");
          ins_caverna(c,giri);
          giri++;
  break;
  case 2: system("clear");
          canc_caverna(c);
  break;
  case 3: system("clear");
         stampa_cunicolo(c);
  break;
  case 4: system("clear");
  sceltat=chiudi_cunicolo(giri);

  break;
  default:
  system("clear");
  printf("SCELTA ERRATA\n");
  break;
    }

  }while(sceltat!=4);
    giri=0;
}

void ins_caverna(int round_ins,int giro,int b,int l){

if(round_ins%2==0){
primo_cunicolo=primo_cunicolo_arvais;
ultimo_cunicolo=ultimo_cunicolo_arvais;
}else{
primo_cunicolo=primo_cunicolo_hartornen;
ultimo_cunicolo=ultimo_cunicolo_hartornen;
}

if(primo_cunicolo==NULL){
  printf("NON sono presenti caverne \n");
primo_cunicolo=ultimo_cunicolo=(struct Caverna *) malloc (sizeof( struct Caverna));
printf("%d\n",primo_cunicolo );
ultimo_cunicolo->avanti=NULL;
ultimo_cunicolo->sinistra=NULL;
ultimo_cunicolo->destra=NULL;


 do{
 printf("DOVE DESIDERI COSTRUIRE LA TUA CAVERNA\n1)AVANTI\n2)DESTRA\n3)SINISTRA\n");
 scanf("%d",&posizione );

     if(posizione==1){
       ultimo_cunicolo->avanti=(struct Caverna *) malloc (sizeof(struct Caverna));
       ultimo_cunicolo=ultimo_cunicolo->avanti;
       ultimo_cunicolo->avanti=NULL;
     }else if(posizione==2){
       ultimo_cunicolo->destra=(struct Caverna *) malloc (sizeof(struct Caverna));
       ultimo_cunicolo=ultimo_cunicolo->destra;
       ultimo_cunicolo->destra=NULL;
     }else{
       ultimo_cunicolo->sinistra=(struct Caverna *) malloc (sizeof(struct Caverna));
       ultimo_cunicolo=ultimo_cunicolo->sinistra;
       ultimo_cunicolo->sinistra=NULL;
     }
   }while((posizione<1)||(posizione>3));

 first=1;

}
else{
  do{

    printf("HAI INSERITO %d CAVERNE\nDOVE DESIDERI COSTRUIRE LA TUA CAVERNA\n1)AVANTI\n2)DESTRA\n3)SINISTRA\n",giro);
    scanf("%d",&posizione );

   if(posizione==1){
      ultimo_cunicolo->avanti=(struct Caverna *) malloc (sizeof(struct Caverna));
      ultimo_cunicolo=ultimo_cunicolo->avanti;
      ultimo_cunicolo->avanti=NULL;

    }else if(posizione==2){
      ultimo_cunicolo->destra=(struct Caverna *) malloc (sizeof(struct Caverna));
      ultimo_cunicolo=ultimo_cunicolo->destra;
      ultimo_cunicolo->destra=NULL;

    }else if(posizione==3){
      ultimo_cunicolo->sinistra=(struct Caverna *) malloc (sizeof(struct Caverna));
      ultimo_cunicolo=ultimo_cunicolo->sinistra;
      ultimo_cunicolo->sinistra=NULL;
    }else{
      printf("RIDAMMI IL VALORE\n");
    }
}while((posizione<1)||(posizione>3));
system("clear");
first=0;
}

do{
printf("DIMMI COME DEVE ESSERE LA CAVERNA\nnormale \nspeciale \naccidentata\n");
scanf("%s",tipologia);
 ultimo_cunicolo->caverna = getEnumtipo_caverna(tipologia);
}while(ultimo_cunicolo->caverna==-1);
system("clear");
do{

int c;
int quantita_melassa;
c=probabilita_melassa(b);
if(c>0 && c<=50){
  quantita_melassa=0;
   ultimo_cunicolo->melassa=quantita_melassa;
}else if(c>50 && c<=80){
  quantita_melassa=1;
   ultimo_cunicolo->melassa=quantita_melassa;
}else{
  quantita_melassa=2;
   ultimo_cunicolo->melassa=quantita_melassa;
}

}while(ultimo_cunicolo->melassa==-1);
do{
int p;
int tipo_imprevisto;
p=probabilita_imprevisto(l);
if(p>0 && p<50){
  tipo_imprevisto=0;
   ultimo_cunicolo->imprevisto = tipo_imprevisto;
}else if(p>50 && p<85){
  tipo_imprevisto=1;
   ultimo_cunicolo->imprevisto = tipo_imprevisto;
}else{
  tipo_imprevisto=2;
   ultimo_cunicolo->imprevisto = tipo_imprevisto;
}
}while(ultimo_cunicolo->imprevisto==-1);




if(round_ins%2==0){
primo_cunicolo_arvais=primo_cunicolo;
ultimo_cunicolo_arvais=ultimo_cunicolo;
ricordo_arvais=primo_cunicolo_arvais;

}else{
primo_cunicolo_hartornen=primo_cunicolo;
ultimo_cunicolo_hartornen=ultimo_cunicolo;
ricordo_hartornen=primo_cunicolo_hartornen;
}
}

void stampa_cunicolo(int round_stamp){
if(round_stamp%2==0){
primo_stampa=primo_cunicolo_arvais;
}else{
primo_stampa=primo_cunicolo_hartornen;
}

printf("                                                     INIZIO\n");
  if(primo_stampa==NULL){
    printf("NON HAI CREATO IL TUO CUNICOLO\n");
  }
  else{
    do{
if(primo_stampa->avanti!=NULL){
      printf("                                                \t|\n                                                \t|\n                                                \t|\n                                                \tv\n                                                        @\n");
}else if(primo_stampa->destra!=NULL){
  printf("                                                        --------------->@\n                                                        |\n                                                        |\n");
}else if(primo_stampa->sinistra!=NULL){

  printf("                                        @<---------------\n                                                        |\n                                                        |\n");
}
if((primo_stampa->avanti==NULL)&&(primo_stampa->sinistra==NULL)&&(primo_stampa->destra==NULL)){
  break;
}else{
  if(primo_stampa->avanti!=NULL){
  primo_stampa=primo_stampa->avanti;
}else if(primo_stampa->destra!=NULL){
  primo_stampa=primo_stampa->destra;
}else if(primo_stampa->sinistra!=NULL){
  primo_stampa=primo_stampa->sinistra;
}
}
printf("LA CAVERNA HA IL SEGUENTE IMPREVISTO :%s\n",getStringtipo_imprevisto(primo_stampa->imprevisto));
printf("LA QUANTITA' DI MELASSA IN QUESTA CAVERNA E':%s\n",getStringquantita_melassa(primo_stampa->melassa) );
printf("LA CAVERNA E' DI TIPO:%s\n",getStringtipo_caverna((int)primo_stampa->caverna) );
    }while(1);
printf("                                                      Fine\n");
printf("\n \n \n" );
  }
}

void canc_caverna(int round_cancella){
  if(round_cancella%2==0){
  primo_cunicolo=primo_cunicolo_arvais;
  ultimo_cunicolo=ultimo_cunicolo_arvais;
  }else{
  primo_cunicolo=primo_cunicolo_hartornen;
  ultimo_cunicolo=ultimo_cunicolo_hartornen;
  }

  if(primo_cunicolo==NULL){
    printf("NON E' PRESENTE ALCUNA CAVERNA\n");
  }else{
cancella=primo_cunicolo;
  do{
      if((cancella->avanti==NULL)&&(cancella->destra==NULL)&&(cancella->sinistra==NULL)){

          free(cancella);

          ultimo_cunicolo->avanti=NULL;
          ultimo_cunicolo->destra=NULL;
          ultimo_cunicolo->sinistra=NULL;
          break;
        }else{
          if(cancella->avanti!=NULL){
          ultimo_cunicolo=cancella;
          cancella=cancella->avanti;
        }else if(cancella->destra!=NULL){
          ultimo_cunicolo=cancella;
          cancella=cancella->destra;
        }else{
          ultimo_cunicolo=cancella;
          cancella=cancella->sinistra;
        }
       }

       if(round_cancella%2==0){
       ultimo_cunicolo_arvais=ultimo_cunicolo;
       }else{
       ultimo_cunicolo_hartornen=ultimo_cunicolo;
       }

      }while(1);
    }
    printf("ULTIMA CAVERNA ELIMINATA\n");

}

int chiudi_cunicolo(int giro){
  printf("SICURO? UNA VOLTA USCITI DALLA MODALITA'\"CREA CUNICOLI\"\nNON POTRAI MAI PIU' RIENTRARE IN QUESTA MODALITA'\n");

    do{
        printf("1)SI\n2)NO\n");
        scanf("%d",&temp);

        if(temp==2){
            r=0;

        }else if(temp==1){
            if((primo_cunicolo==NULL)||(giro<0)){
                system("clear");
                printf("IMPOSSIBILE CHIUDERE IL CUNICOLO,CI DEVONO ESSERE ALMENO 10 CAVERNE\n");
                r=0;
            }else{
                r= 4;
                system("clear");
                printf("CHIUSURA MODALITA' PERCORSO\n");
            }
        }else{
            system("clear");
            printf("VALORE NON VALIDO RIPROVA...\n");
        }

    }while((temp!=1)&&(temp!=2));

    return r;
}

void gioca(int t){

if((numero==1)&&(numero1==2)){
  if(regole==0){
  regolescontrofinale();
  regole++;
  }
  scontrofinale(t);}
else{
  if((conta_avanza==1)||(conta_avanza==0)){
    if(t%2==0){

    q_arvais.serbatoio_energia=serbatoio_ene;
    q_arvais.serbatoio_raccolta=serbatoio_rac;
  }else{
    q_hartornen.serbatoio_energia=serbatoio_ene;
    q_hartornen.serbatoio_raccolta=serbatoio_rac;
  }
  conta_avanza++;
}
if(t%2==0){
  nome_turno="ARVAIS";
  primo_avanza=primo_cunicolo_arvais;
  melassa_generica.serbatoio_energia=q_arvais.serbatoio_energia;
  melassa_generica.serbatoio_raccolta=q_arvais.serbatoio_raccolta;
}else{
  nome_turno="HARTORNEN";
  primo_avanza=primo_cunicolo_hartornen;
  melassa_generica.serbatoio_energia=q_hartornen.serbatoio_energia;
  melassa_generica.serbatoio_raccolta=q_hartornen.serbatoio_raccolta;
numero_turno_gioca++;
}
  do{

  printf("SIAMO AL TURNO [%d]°  PLAYERS  [%s]\n\n\t\t\t\tSCEGLI COSA FARE :  \n\n\t\t\t\t1)AVANZARE \n\n\t\t\t\t2)ABBATTERE (COSTO MELASSA=1)\n\n\t\t\t\t",numero_turno_gioca,nome_turno);//quantita_melassa->serbatoio_energia);
  scanf("%d",&variabile_gioco);

  switch (variabile_gioco) {
    case 1:
    if(t%2==0){
    if(numero==0) avanza(t);
    else {printf("ARVAIS SEI USCITO...ASPETTA IL TUO AVVERSARIO PER FARE LO SCONTRO FINALE\n");
    printf("PREMERE UN NUMERO GENERICO E POI INVIO PER PASSARE IL TURNO AL TUO AVVERSARIO");
    scanf("%d",&passaggio_turno);
  }
}else{
    if(numero1==0)avanza(t);
    else {printf("HARTORNEN SEI USCITO...ASPETTA IL TUO AVVERSARIO PER FARE LO SCONTRO FINALE\n");
    printf("PREMERE UN NUMERO GENERICO E POI INVIO PER PASSARE IL TURNO AL TUO AVVERSARIO");
    scanf("%d",&passaggio_turno);
  }
  }
    break;
    case 2:
    servi++;
    if(t%2==0){
      if(numero==0) abbatti(t);
      else {printf("ARVAIS SEI USCITO...ASPETTA IL TUO AVVERSARIO PER FARE LO SCONTRO FINALE\n");
      printf("PREMERE UN NUMERO GENERICO E POI INVIO PER PASSARE IL TURNO AL TUO AVVERSARIO");
      scanf("%d",&passaggio_turno);
    }
  }else{
      if(numero1==0) abbatti(t);
      else {printf("HARTORNEN SEI USCITO...ASPETTA IL TUO AVVERSARIO PER FARE LO SCONTRO FINALE\n");
      printf("PREMERE UN NUMERO GENERICO E POI INVIO PER PASSARE IL TURNO AL TUO AVVERSARIO");
      scanf("%d",&passaggio_turno);
    }
    }
    break;
    default:
    printf("NON HAI INSERITO IL VALORE CORRETTO\n");
    break;
    }
}while((variabile_gioco!=1)&&(variabile_gioco!=2)&&(variabile_gioco!=3));
}

if(t%2==0){
  primo_cunicolo_arvais=primo_avanza;
  q_arvais=melassa_generica;
}else{
  primo_cunicolo_hartornen=primo_avanza;
  q_hartornen=melassa_generica;
}
uscita2+=2.5;
}

void avanza(int round){

  if((primo_avanza->avanti!=NULL)||(primo_avanza->sinistra!=NULL)||(primo_avanza->destra!=NULL)){
    pbr=probabilita_imprevisto_improvviso();
   if ((pbr>0)&&(pbr<25)){
      do{
      printf("E' ACCADUTO UN CROLLO IMPROVVISO SEI COSTRETTO AD AGGIRARLO,SENNO'MORIRAI...AGGIRI? \n1)SI\n2)NO\n");
      scanf("%d",&scelta_aggira );
      if(scelta_aggira==1){
        aggira(round);

      }else if(scelta_aggira==2){
        printf("SEI STATO UN OTTIMO GIOCATORE MA SEI MORTO\nHA VINTO AUTOMATICAMENTE IL TUO AVVERSARIO,CONGRATULAZIONI\n");
        congratulations(round);

        }else{
        printf("IL VALORE INSERITO NON VA BENE,RIDAMMELO\n");
      }
    }while((scelta_aggira!=1)&&(scelta_aggira!=2));
  }else{
  if(primo_avanza->avanti!=NULL){
    printf("LA CAVERNA E' AVANTI\n");
    primo_avanza=primo_avanza->avanti;
  }else if(primo_avanza->sinistra!=NULL){
    printf("LA CAVERNA E' SINISTRA\n");
    primo_avanza=primo_avanza->sinistra;
  }else if(primo_avanza->destra!=NULL){
    printf("LA CAVERNA E' DESTRA\n");
    primo_avanza=primo_avanza->destra;
  }

  printf("LA CAVERNA E'DI TIPO:%s\n",getStringtipo_caverna((int)primo_avanza->caverna ));
  printf("NELLA CAVERNA E' ACCADUTO QUALCOSA:%s\n",getStringtipo_imprevisto(primo_avanza->imprevisto ));
  printf("QUANTITA' MELASSA TROVATA :%s\n\n",getStringquantita_melassa(primo_avanza->melassa) );

  if(primo_avanza->caverna==1){
    melassa_generica.serbatoio_energia++;
  }else if(primo_avanza->caverna==2){
  melassa_generica.serbatoio_energia--;
  }
if(primo_avanza->imprevisto==1){
  melassa_generica.serbatoio_energia--;
}else if(primo_avanza->imprevisto==2){
  melassa_generica.serbatoio_energia=0;
  melassa_generica.serbatoio_raccolta=0;
}
if(primo_avanza->melassa==1){
do{
  printf("QUANTITA' MELASSA TROVATA :%s\nDOVE DESIDERI DEPOSITARE LA MELASSA TROVATA?\n1)SERBATOIO ENERGIA\n2)SERBATIO RACCOLTA\n\n",getStringquantita_melassa(primo_avanza->melassa) );
scanf("%d",&serbatoio);
if(serbatoio==1)
  melassa_generica.serbatoio_energia++;
else if(serbatoio==2)
  melassa_generica.serbatoio_raccolta++;
 else
 printf("NON MI HA DATO IL VALORE CORRETTO RIDAMMELO\n");
}while((serbatoio!=1)&&(serbatoio!=2));
}else if(primo_avanza->melassa==2){
  do{
    printf("QUANTITA' MELASSA TROVATA :%s\nDOVE DESIDERI DEPOSITARE LA MELASSA TROVATA?\n1)SERBATOIO ENERGIA\n2)SERBATIO RACCOLTA\n\n",getStringquantita_melassa(primo_avanza->melassa) );
  scanf("%d",&serbatoio);
  if(serbatoio==1)
    melassa_generica.serbatoio_energia+=3;
  else if(serbatoio==2)
    melassa_generica.serbatoio_raccolta+=3;
   else
   printf("NON MI HA DATO IL VALORE CORRETTO RIDAMMELO\n");
  }while((serbatoio!=1)&&(serbatoio!=2));}

  if(melassa_generica.serbatoio_energia>4){
    printf("PUOI AVERE AL MASSIMO 4 UNITA' DI MELASSA NELLA ENERGIA\n");
    melassa_generica.serbatoio_energia=4;
  }else if(melassa_generica.serbatoio_raccolta>10){
    printf("PUOI AVERE AL MASSIMO 10 UNITA' DI MELASSA NELLA RACCOLTA\n");
    melassa_generica.serbatoio_raccolta=10;
  }
}
}else{
    printf("SEI ARRIVATO ALLA FINE\n");
    printf("LA CAVERNA E'DI TIPO:%s\n",getStringtipo_caverna((int)primo_avanza->caverna ));
    printf("NELLA CAVERNA E' ACCADUTO QUALCOSA:%s\n",getStringtipo_imprevisto(primo_avanza->imprevisto ));
    printf("QUANTITA' MELASSA TROVATA :%s\n\n",getStringquantita_melassa(primo_avanza->melassa) );
  }

  printf("SERBATOIO ENERGIA==%d\n",melassa_generica.serbatoio_energia);
  printf("SERBATOIO RACCOLTA=%d\n\n\n\n",melassa_generica.serbatoio_raccolta);
  if(melassa_generica.serbatoio_energia<0){
    printf("IL SERBATOIO SI E' DISTRUTO PER DEBITO DI MELASSA\nSEI MORTO\n");
    congratulations(round);
  }
scanf("%d",&variabile );
}

void abbatti(int round_abbatti){



   if(round_abbatti%2==0){
     primo_abbatti=primo_avanza;
     melassa_generica.serbatoio_energia=q_arvais.serbatoio_energia;
     melassa_generica.serbatoio_raccolta=q_arvais.serbatoio_raccolta;
   }else{
     primo_abbatti=primo_avanza;
     melassa_generica.serbatoio_energia=q_hartornen.serbatoio_energia;
     melassa_generica.serbatoio_raccolta=q_hartornen.serbatoio_raccolta;
   }
melassa_generica.serbatoio_energia--;
   if((primo_abbatti->avanti==NULL)&&(primo_abbatti->destra==NULL)&&(primo_abbatti->sinistra==NULL)){
     do{
     printf("\t\t\t\tPUOI ABBATTERE DOVE VUOI:\n1)AVANTI\n2)DESTRA\n3)SINISTRA\n");
     scanf("%d",&pos);
     if(pos==1){
       primo_abbatti->avanti=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->avanti;
       primo_abbatti->avanti=NULL;
       printf("\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\tv\n\t\t\t\t\t\t\t\t@\n");
     }else if(pos==2){
       primo_abbatti->destra=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->destra;
       primo_abbatti->destra=NULL;

       printf("                                                        --------------->@\n                                                        |\n                                                        |\n");
     }else if(pos==3){
       primo_abbatti->sinistra=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->sinistra;

       primo_abbatti->sinistra=NULL;

       printf("                                        @<---------------\n                                                        |\n                                                        |\n");

     }
     else{
       puts("RIDAMMI IL VALORE\n");
     }

   }while((pos!=1)&&(pos!=2)&&(pos!=3));

   }else if(primo_abbatti->avanti!=NULL){
     do{
     printf("\t\t\t\tPUOI ABBATTERE SOLO A:\n1)DESTRA\n2)SINISTRA\n");
     scanf("%d",&pos);
     if(pos==1){
       primo_abbatti->destra=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->destra;
       primo_abbatti->destra=NULL;

       printf("                                                        --------------->@\n                                                        |\n                                                        |\n");
     }else if(pos==2){
       primo_abbatti->sinistra=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->sinistra;

       primo_abbatti->sinistra=NULL;
        printf("                                        @<---------------\n                                                        |\n                                                        |\n");

     }else{
       puts("RIDAMMI IL VALORE\n");
     }
   }while((pos!=1)&&(pos!=2));
   }else if(primo_abbatti->sinistra!=NULL){
     do{
     printf("\t\t\t\tPUOI ABBATTERE SOLO A:\n1)AVANTI \n2)DESTRA\n");
     scanf("%d",&pos);
     if(pos==1){
       primo_abbatti->avanti=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->avanti;
       primo_abbatti->avanti=NULL;
       printf("\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\tv\n\t\t\t\t\t\t\t\t@\n");

     }else if(pos==2){
       primo_abbatti->destra=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->destra;
       primo_abbatti->destra=NULL;
       printf("                                                        --------------->@\n                                                        |\n                                                        |\n");
     }else{
       puts("RIDAMMI IL VALORE\n");
     }
   }while((pos!=1)&&(pos!=2));
   }else if(primo_abbatti->destra!=NULL){
     do{
     printf("\t\t\t\tPUOI ABBATTERE SOLO A:\n1)AVANTI \n2)SINISTRA\n");

     scanf("%d",&pos);
     if(pos==1){
       primo_abbatti->avanti=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->avanti;
       primo_abbatti->avanti=NULL;
       printf("\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\t|\n\t\t\t\t\t\t\t\tv\n\t\t\t\t\t\t\t\t@\n");

     }else if(pos==2){
       primo_abbatti->sinistra=(struct Caverna *) malloc (sizeof(struct Caverna));
       primo_abbatti=primo_abbatti->sinistra;
       primo_abbatti->sinistra=NULL;
       printf("                                        @<---------------\n                                                        |\n                                                        |\n");
     }else{
       puts("RIDAMMI IL VALORE\n");
     }
   }while((pos!=1)&&(pos!=2));
   }
primo_abbatti->sinistra=NULL;
primo_abbatti->avanti=NULL;
primo_abbatti->destra=NULL;
   do{
   prob_stato=probabilita_stato(m);
   if((prob_stato>0) && (prob_stato<=20)){
     tipo_abbatti_prob=2;
      primo_abbatti->caverna_abbatti= tipo_abbatti_prob;
   }else if((prob_stato>20) && (prob_stato<=(20+uscita2))){
     tipo_abbatti_prob=3;
      primo_abbatti->caverna_abbatti =tipo_abbatti_prob;
   }else if((prob_stato>(20+uscita2)) && (prob_stato<=(80-((20+uscita2)/2)))){
     tipo_abbatti_prob=1;
      primo_abbatti->caverna_abbatti = tipo_abbatti_prob;
   }else{
     tipo_abbatti_prob=0;
      primo_abbatti->caverna_abbatti = tipo_abbatti_prob;
   }

 }while(primo_abbatti->caverna_abbatti==-1);

 do{

 c=probabilita_melassa(q);
 if(c>0 && c<=40){
   quantita_melassa=0;
    primo_abbatti->melassa = quantita_melassa;
 }else if(c>40 && c<=80){
   quantita_melassa=1;
    primo_abbatti->melassa =quantita_melassa;
 }else{
   quantita_melassa=2;
    primo_abbatti->melassa = quantita_melassa;
 }

 }while(primo_abbatti->melassa==-1);
 do{


 p=probabilita_imprevisto(n);
 if(p>0 && p<40){
   tipo_imprevisto=0;
    primo_abbatti->imprevisto = tipo_imprevisto;
 }else if(p>40 && p<80){
   tipo_imprevisto=1;
    primo_abbatti->imprevisto = tipo_imprevisto;
 }else{
   tipo_imprevisto=2;
    primo_abbatti->imprevisto = tipo_imprevisto;
 }
 }while(primo_abbatti->imprevisto==-1);


 printf("LA CAVERNA E'DI TIPO:%s\n",getStringtipo_caverna_abbatti((int)primo_abbatti->caverna_abbatti ));
 printf("LA CAVERNA HO IL SEGUENTE IMPREVISTO :%s\n",getStringtipo_imprevisto(primo_abbatti->imprevisto));
 printf("LA QUANTITA' DI MELASSA IN QUESTA CAVERNA E':%s\n",getStringquantita_melassa(primo_abbatti->melassa) );
 if(primo_abbatti->caverna_abbatti==1){
   melassa_generica.serbatoio_energia++;
 }else if(primo_abbatti->caverna_abbatti==2){
   melassa_generica.serbatoio_energia--;
 }
 if(primo_abbatti->imprevisto==0){
 }else if(primo_abbatti->imprevisto==1){
   melassa_generica.serbatoio_energia--;
 }else{
   melassa_generica.serbatoio_energia=0;
 }
 if(melassa_generica.serbatoio_energia>4){
   printf("\t\tIL SERBATIO PUO' CONTENERE AL MASSIMO 4 UNITA' DI MELASSA\nQUINDI VERRA' SCARTATA QUELLA IN ECCESSO\n");
   melassa_generica.serbatoio_energia=4;
 }




 printf("\t\tSERBATOIO ENERGIA==%d\n",melassa_generica.serbatoio_energia);
 printf("\t\tSERBATOIO RACCOLTA=%d\n\n\n\n",melassa_generica.serbatoio_raccolta);

 if(primo_abbatti->melassa!=0){
 do{

     printf("DOVE DESIDERI DEPOSITARLO?\n1)SERBATOIO ENERGIA\n2)SERBATOIO RACCOLTA\n");
     scanf("%d",&scelta_serbatio);


 if(scelta_serbatio==1){
   if(primo_abbatti->melassa==0){
 }else if(primo_abbatti->melassa==1){
   melassa_generica.serbatoio_energia=melassa_generica.serbatoio_energia+1;
 }else{
     melassa_generica.serbatoio_energia=melassa_generica.serbatoio_energia+3;
 }
 if(primo_abbatti->caverna==1){
   melassa_generica.serbatoio_energia++;
 }
 }else if(scelta_serbatio==2){
   if(primo_abbatti->melassa==0){
   melassa_generica.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
 }else if(primo_abbatti->melassa==1){
   melassa_generica.serbatoio_raccolta=melassa_generica.serbatoio_raccolta+1;
 }else{
     melassa_generica.serbatoio_raccolta=melassa_generica.serbatoio_raccolta+3;
 }

 }else{
   printf("NON HAI INSERITO IL VALORE CORRETTO\n");
 }
}while((scelta_serbatio<1)||(scelta_serbatio>2));
}



 if(melassa_generica.serbatoio_energia>4){
   printf("IL SERBATIO PUO' CONTENERE AL MASSIMO 4 UNITA' DI MELASSA\nQUINDI VERRA' SCARTATA QUELLA IN ECCESSO\n");
   melassa_generica.serbatoio_energia=4;
 }

 printf("SERBATOIO ENERGIA==%d\n",melassa_generica.serbatoio_energia);
 printf("SERBATOIO RACCOLTA=%d\nPREMERE UN NUMERO GENERICO E POI INVIO PER PASSARE IL TURNO AL TUO AVVERSARIO\n",melassa_generica.serbatoio_raccolta);
 scanf("%d",&passaggio_turno);

if(primo_abbatti->caverna_abbatti==3){
esci(round_abbatti);
}



 if(round_abbatti%2==0){
   primo_avanza=primo_abbatti;
   primo_cunicolo_arvais=primo_avanza;
   q_arvais.serbatoio_energia=melassa_generica.serbatoio_energia;
   q_arvais.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
 }else{
   primo_avanza=primo_abbatti;
   primo_cunicolo_hartornen=primo_avanza;
   q_hartornen.serbatoio_energia=melassa_generica.serbatoio_energia;
   q_hartornen.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
 }
 if(melassa_generica.serbatoio_energia<0){
   printf("IL SERBATOIO SI E' DISTRUTO PER DEBITO DI MELASSA\nSEI MORTO\n");
   congratulations(round_abbatti);
 }
}

void aggira(int giocatore,int k,int x,int j){

  primo_cunicolo_aggira=(struct Caverna *) malloc (sizeof( struct Caverna));
  do{
  prob_stato=probabilita_stato(j);
  if((prob_stato>0) && (prob_stato<=20)){
    tipo_abbatti_prob=2;
     primo_cunicolo_aggira->caverna_abbatti= tipo_abbatti_prob;
  }else if((prob_stato>20) && (prob_stato<=60)){
    tipo_abbatti_prob=1;
     primo_cunicolo_aggira->caverna_abbatti =tipo_abbatti_prob;
  }else if((prob_stato>60) && (prob_stato<=100)){
    tipo_abbatti_prob=0;
     primo_cunicolo_aggira->caverna_abbatti = tipo_abbatti_prob;
  }
}while(primo_cunicolo_aggira->caverna_abbatti==-1);
do{

  c=probabilita_melassa(k);
  if(c>0 && c<=50){
    quantita_melassa=0;
     primo_cunicolo_aggira->melassa = quantita_melassa;
  }else if(c>50 && c<=80){
    quantita_melassa=1;
     primo_cunicolo_aggira->melassa =quantita_melassa;
  }else{
    quantita_melassa=2;
     primo_cunicolo_aggira->melassa = quantita_melassa;
  }

}while(primo_cunicolo_aggira->melassa==-1);
  do{


  p=probabilita_imprevisto(x);
  if(p>0 && p<50){
    tipo_imprevisto=0;
     primo_cunicolo_aggira->imprevisto = tipo_imprevisto;
  }else if(p>50 && p<85){
    tipo_imprevisto=1;
     primo_cunicolo_aggira->imprevisto = tipo_imprevisto;
  }else{
    tipo_imprevisto=2;
     primo_cunicolo_aggira->imprevisto = tipo_imprevisto;
  }
}while(primo_cunicolo_aggira->imprevisto==-1);
printf("LA CAVERNA E'DI TIPO:%s\n",getStringtipo_caverna_abbatti((int)primo_cunicolo_aggira->caverna_abbatti ));
printf("LA CAVERNA HO IL SEGUENTE IMPREVISTO :%s\n",getStringtipo_imprevisto(primo_cunicolo_aggira->imprevisto));
printf("LA QUANTITA' DI MELASSA IN QUESTA CAVERNA E':%s\n\n",getStringquantita_melassa(primo_cunicolo_aggira->melassa) );

printf("ERBATOIO ENERGIA==%d\n",melassa_generica.serbatoio_energia);
printf("SERBATOIO RACCOLTA=%d\n\n\n\n",melassa_generica.serbatoio_raccolta);

if(primo_cunicolo_aggira->caverna_abbatti==1){
  melassa_generica.serbatoio_energia++;
}else if(primo_cunicolo_aggira->caverna_abbatti==2){
melassa_generica.serbatoio_energia--;
}
if(primo_cunicolo_aggira->imprevisto==1){
melassa_generica.serbatoio_energia--;
}else if(primo_cunicolo_aggira->imprevisto==2){
melassa_generica.serbatoio_energia=0;
melassa_generica.serbatoio_raccolta=0;
}

if(primo_cunicolo_aggira->melassa!=0){
do{
      printf("DOVE DESIDERI DEPOSITARLO?\n1)SERBATOIO ENERGIA\n2)SERBATOIO RACCOLTA\n");
      scanf("%d",&scelta_serbatio);

  if(scelta_serbatio==1){
    if(primo_cunicolo_aggira->melassa==0){
  }else if(primo_cunicolo_aggira->melassa==1){
    melassa_generica.serbatoio_energia=melassa_generica.serbatoio_energia+1;
  }else{
      melassa_generica.serbatoio_energia=melassa_generica.serbatoio_energia+3;
  }
  if(primo_cunicolo_aggira->caverna==1){
    melassa_generica.serbatoio_energia++;
  }
  }else if(scelta_serbatio==2){
    if(primo_cunicolo_aggira->melassa==0){
    melassa_generica.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
  }else if(primo_cunicolo_aggira->melassa==1){
    melassa_generica.serbatoio_raccolta=melassa_generica.serbatoio_raccolta+1;
  }else{
      melassa_generica.serbatoio_raccolta=melassa_generica.serbatoio_raccolta+3;
  }
  }else{
    printf("NON HAI INSERITO IL VALORE CORRETTO\n");
  }
}while((scelta_serbatio!=1)&&(scelta_serbatio!=2));
}

  if(melassa_generica.serbatoio_energia<0){
    printf("IL SERBATOIO SI E' DISTRUTO PER DEBITO DI MELASSA\nSEI MORTO\n");
    congratulations(giocatore);

  }


  if(melassa_generica.serbatoio_energia>4){
    printf("IL SERBATIO PUO' CONTENERE AL MASSIMO 4 UNITA' DI MELASSA\nQUINDI VERRA' SCARTATA QUELLA IN ECCESSO\n");
    melassa_generica.serbatoio_energia=4;
  }

  printf("SERBATOIO ENERGIA==%d\n",melassa_generica.serbatoio_energia);
  printf("SERBATOIO RACCOLTA=%d\nAL PROSSIMO TURNO SE DICIDI DI AVANTI CONTINUERAI NEL PERCORSO DA TE CREATO\nSE NON SONO PRENSENTI CAVERNE SUCCESSIVE DOVRAI ABBATTERE PER FORZA\nORA PREMI UN NUMERO GENERICO PER PASSARE IL TURNO\n",melassa_generica.serbatoio_raccolta);
scanf("%d",&passaggio_turno);



if(primo_avanza->avanti!=NULL){
  primo_avanza=primo_avanza->avanti;
}else if(primo_avanza->destra!=NULL){
  primo_avanza=primo_avanza->destra;
}else if(primo_avanza->sinistra!=NULL){
  primo_avanza=primo_avanza->sinistra;
}else{
  printf("HAI TERMINATO LE CAVERNE\n");
  primo_avanza->avanti=NULL;
  primo_avanza->destra=NULL;
  primo_avanza->sinistra=NULL;
}

if(giocatore%2==0){
  primo_cunicolo_arvais=primo_avanza;
  q_arvais.serbatoio_energia=melassa_generica.serbatoio_energia;
  q_arvais.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
}else{
  primo_cunicolo_hartornen=primo_avanza;
  q_hartornen.serbatoio_energia=melassa_generica.serbatoio_energia;
  q_hartornen.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
}
}

void regolescontrofinale(){
  printf("SCONTRO FINALE\nRULES:\n1)CON LA MELASSA RACCOLTA PUOI FARE DELLE MOSSE DI ATTACCO E DIFENDERTI DA ESSE\n2)AD OGNI TURNO VI SARANNO DONATI 2qm ,1 in energia,1 in raccolta\n3)PUOI USARE 1 MOSSA DI ATTACCO PER TURNO DELLE 3 DISPONIBILI:\ni)colpo scavatrice(COSTO:1qm) TOGLIE 1 DI VITA GRAZIE AL L'URTO FRA SCAVATRICI\n\n\nii)razzo scavatrice(COSTO:2qm)TOGLIE 2 DI VITA GRAZIE AL ALLA TRIVELLA DELLA SCAVATRICE CHE COLPISCE QUELLA AVVERSARIA\n\n\niii)melassa scavatrice(COSTO 3qm)TOGLIE 3 DI VITA GRAZIE AL FURTO NEL SERBATOIO ENERGIA DI 3qm\n\n\n4)LA VITA DEL GIOCATORE CORRISPONDE CON LA QUANTITA' DI MELASSA DI ENERGIA,PER DIFENDERSI DAGLI ATTACCHI BISOGNA SPENDERE SEMPRE 2 qm,ALTRIMENTI SUBIRAI I DANNI\n\n5)VINCERA' COLUI CHE PORTERA' LA VITA DELL'AVVERSARIO SOTTO 0\n");
}

int scontrofinale(int turno){

      q_arvais.serbatoio_energia++;
      q_hartornen.serbatoio_energia++;

      q_arvais.serbatoio_raccolta++;
      q_hartornen.serbatoio_raccolta++;

    printf("\nVI E' STATA INCREMENTATA LA MELASSA SIA IN VITA SIA IN RACCOLTA DI 1 qm\n\n\n");
    printf("LIFE ARVAIS %d\nRACCOLTA ARVAIS %d\n\n",q_arvais.serbatoio_energia,q_arvais.serbatoio_raccolta);
    printf("LIFE HARTORNEN %d\nRACCOLTA HARTORNEN %d\n\n",q_hartornen.serbatoio_energia,q_hartornen.serbatoio_raccolta);

  if(turno%2==0){
    do{
    printf("E' IL TURNO DI ARVAINS\nSE VUOI ATTACCARE DIMMI CHE MOSSA USI PREMENDO:\n\n1)colpo scavatrice(COSTO:1qm)\n2)razzo scavatrice(COSTO:2qm)\n3)melassa di scavatrice(COSTO 3qm)\n4)passa il turno (COSTO 0qm)\n\n" );
    scanf("%d",&colpo );
    if(colpo==1){
      printf("HAI SCELTO colpo scavatrice LA TUA qm CALERA' DI UNA UNITA'\n\n");
  }else if(colpo==2){
    printf("HAI SCELTO razzo scavatrice LA TUA qm CALERA' DI DUE UNITA'\n\n");
  }else if(colpo==3){
    printf("HAI SCELTO melassa scavatrice LA TUA qm CALERA' DI TRE UNITA'\n\n");
  }else if(colpo==4){
    printf("HAI DECISO DI PASSARE IL TURNO\n");
  }else{printf("RIDAMMI IL VALORE\n");
}
}while((colpo!=1)&&(colpo!=2)&&(colpo!=3)&&(colpo!=4));
if(colpo!=4){
    do{
    printf("HARTORNEN INTENDI DIVENDERTI E QUINDI USARE 2qm OPPURE ACCETTARE I DANNI?\nDIGITA\n1)difesa\n2)subisco\n");
    scanf("%d",&difesa);
    }while((difesa!=2)&&(difesa!=1));
}
  }else{
    do{
    printf("E' IL TURNO DI HARTORN\nSE VUOI ATTACCARE DIMMI CHE MOSSA USI PREMENDO:\n1)colpo di scavatrice(COSTO:1qm)\n2)razzo  scavatrice(COSTO:2qm)\n3)melassa di scavatrice(COSTO 3qm)\n4)passa il turno (COSTO 0qm)\n\n" );
    scanf("%d",&colpo );
    if(colpo==1){
      printf("HAI SCELTO colpo scavatrice LA TUA qm CALERA' DI UNA UNITA'\n");
    }else if(colpo==2){
      printf("HAI SCELTO razzo scavatrice LA TUA qm CALERA' DI DUE UNITA'\n");
    }else if(colpo==3){
      printf("HAI SCELTO melassa scavatrice LA TUA qm CALERA' DI TRE UNITA'\n");
    }else if(colpo==4){
      printf("HAI DECISO DI PASSARE IL TURNO\n");
    }else{
    printf("RIDAMMI IL VALORE\n");
  }
}while((colpo!=1)&&(colpo!=2)&&(colpo!=3)&&(colpo!=4));
if(colpo!=4){
    do{
    printf("ARVAINS INTENDI DIFENDERTI E QUINDI USARE 2qm OPPURE ACCETTARE I DANNI?\nDIGITA\n1)difesa\n2)subisco\n");
    scanf("%d",&difesa);
     }while((difesa!=2)&&(difesa!=1));
 }
}
if(colpo!=4){
  if(turno%2==0){

      melassa_generica.serbatoio_energia=q_hartornen.serbatoio_energia;
      melassa_generica.serbatoio_raccolta=q_hartornen.serbatoio_raccolta;

  if(difesa==1){
    melassa_generica.serbatoio_raccolta-=2;
    if((melassa_generica.serbatoio_energia<=0)&&(melassa_generica.serbatoio_raccolta<0)){
      printf("HAI PERSO PER MANCANZA DI MELASSA\n");
    termina_gioco(turno);
    }else if((melassa_generica.serbatoio_energia>melassa_generica.serbatoio_raccolta)&&(melassa_generica.serbatoio_raccolta<1)){
      printf("DATO CHE NON POSSIEDI PIU' MELASSA RACCOLTA TARSFERIREMO 1qm DA LIFE E PORTEREMO QULLA RACCOLTA A QUOTA 1qm\n" );
          melassa_generica.serbatoio_raccolta=1;
          melassa_generica.serbatoio_energia--;
    }
  }else{

    if(colpo==1){melassa_generica.serbatoio_energia-=1;}else if(colpo==2){melassa_generica.serbatoio_energia-=2;}else if(colpo==3){melassa_generica.serbatoio_energia-=3;}
  }

  printf("LA VITA DI HARTORNEN E' %d\nMENTRE QUELLA qm RACCOLTA E'  %d\n",melassa_generica.serbatoio_energia,melassa_generica.serbatoio_raccolta );
  printf("PREMERE UN NUMERO GENERICO E POI INVIO PER PASSARE IL TURNO AL TUO AVVERSARIO\n");
  scanf("%d",&passaggio_turno);

  q_hartornen.serbatoio_energia=melassa_generica.serbatoio_energia;
  q_hartornen.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;

}else{

      melassa_generica.serbatoio_energia=q_arvais.serbatoio_energia;
      melassa_generica.serbatoio_raccolta=q_arvais.serbatoio_raccolta;

  if(difesa==1){
    melassa_generica.serbatoio_raccolta-=2;
    if((melassa_generica.serbatoio_energia<=0)&&(melassa_generica.serbatoio_raccolta<0)){
      printf("HAI PERSO PER MANCANZA DI MELASSA\n");
      congratulations(turno);
      termina_gioco(turno);
    }else if((melassa_generica.serbatoio_energia>melassa_generica.serbatoio_raccolta)&&(melassa_generica.serbatoio_raccolta<1)){
      printf("DATO CHE NON POSSIEDI PIU' MELASSA RACCOLTA TARSFERIREMO 1qm DA LIFE E PORTEREMO QULLA RACCOLTA A QUOTA 1qm\n" );
          melassa_generica.serbatoio_raccolta=1;
          melassa_generica.serbatoio_energia--;
    }
  }else{

    if(colpo==1){melassa_generica.serbatoio_energia-=1;}else if(colpo==2){melassa_generica.serbatoio_energia-=2;}else if(colpo==3){melassa_generica.serbatoio_energia-=3;}

  }
  printf("LA VITA DI ARVAIS E' %d\nMENTRE QUELLA qm RACCOLTA E' %d\n",melassa_generica.serbatoio_energia,melassa_generica.serbatoio_raccolta );

}




if(turno%2==0){
  q_arvais.serbatoio_energia=melassa_generica.serbatoio_energia;
  q_arvais.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
}else{
  q_hartornen.serbatoio_energia=melassa_generica.serbatoio_energia;
  q_hartornen.serbatoio_raccolta=melassa_generica.serbatoio_raccolta;
}

if(q_arvais.serbatoio_energia<0){
  printf("ARVAIS HAI PERSO\n");
  return termina_gioco(turno);
}
if(q_hartornen.serbatoio_energia<0){
  printf("HARTORNEN HAI PERSO\n");
  return termina_gioco(turno);
}
}

printf("PREMERE UN NUMERO GENERICO E POI INVIO PER PASSARE IL TURNO AL TUO AVVERSARIO\n");
scanf("%d",&passaggio_turn);
}

void esci(int turno_esci){
  do{
    printf("HAI TROVATO UN'USCITA VUOI USCIRE?\n1)SI\n2)NO\n");
    scanf("%d",&sceltauscita);
    if(sceltauscita==1){
      printf("PERFETTO ASPETTIAMO IL TUO AVVERSARIO PER FARE LO SCONTRO FINALE\n");
      if(turno_esci%2==0)
      numero=1;
      else
      numero1=2;
    }else if(sceltauscita==2){
      printf("OK CONTINUIAMO A SCAVARE\n");
    }else{
      printf("RIDAMMI IL VALORE\n");
    }

  }while((sceltauscita!=1)&&(sceltauscita!=2));
}

void congratulations(int turno_vincitore){
  if(turno_vincitore%2==0){
    nome_vincitore="HARTORNEN";
  }else{
    nome_vincitore="ARVAIS";
  }
printf("%s CONGRATULAZIONI HAI VINTO LA PARTITA\n",nome_vincitore );
scanf("%d",&passaggio_turno);

}

int termina_gioco(int turno_termina){
  if(ricordo_arvais!=NULL){
while((ricordo_arvais->avanti!=NULL)||(ricordo_arvais->destra!=NULL)||(ricordo_arvais->sinistra!=NULL)){
printf("ricordo_arvais %d\n",ricordo_arvais );
ricordo=ricordo_arvais;
if(ricordo_arvais->avanti!=NULL)
ricordo_arvais=ricordo_arvais->avanti;
else if(ricordo_arvais->sinistra!=NULL)
ricordo_arvais=ricordo_arvais->sinistra;
else if(ricordo_arvais->destra!=NULL)
ricordo_arvais=ricordo_arvais->destra;
free(ricordo);
}
free(ricordo_arvais);
}

if(ricordo_hartornen!=NULL){
while((ricordo_hartornen->avanti!=NULL)||(ricordo_hartornen->destra!=NULL)||(ricordo_hartornen->sinistra!=NULL)){
printf("ricordo_hartornen %d\n",ricordo_hartornen );
ricordo=ricordo_hartornen;
if(ricordo_hartornen->avanti!=NULL)
ricordo_hartornen=ricordo_hartornen->avanti;
else if(ricordo_hartornen->sinistra!=NULL)
ricordo_hartornen=ricordo_hartornen->sinistra;
else if(ricordo_hartornen->destra!=NULL)
ricordo_hartornen=ricordo_hartornen->destra;
free(ricordo);
}
free(ricordo_hartornen);
}

do{
printf("VOUI GIOCARE DI NUOVO OPPURE VUOI FINIRE ADESSO?\n0)END\n1)NEW GAME\n");
scanf("%d",&rigioca );
system("clear");
}while((rigioca!=0)&&(rigioca!=1));
numero=0;
numero1=0;
conta_avanza=0;
giri=0;
numero_turno_gioca=0;
prob_incontro=0;
q_arvais.serbatoio_energia=4;
q_hartornen.serbatoio_energia=0;
q_arvais.serbatoio_raccolta=4;
q_hartornen.serbatoio_raccolta=0;
ricordo_arvais=NULL;
ricordo_hartornen=NULL;
return rigioca;



}
